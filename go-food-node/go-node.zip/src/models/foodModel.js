const db = require('../config/db');

exports.addFood = async (foodData) => {
    const { name, restaurant_name, image_url, location, price, category, rating } = foodData;
    const [result] = await db.query('INSERT INTO food_items (name, restaurant_name, image_url, location, price, category, rating) VALUES (?, ?, ?, ?, ?, ?, ?)', 
                                    [name, restaurant_name, image_url, location, price, category, rating]);
    return result.insertId;
};

exports.updateFood = async (id, foodData) => {
    const { name, restaurant_name, image_url, location, price, category, rating } = foodData;
    await db.query('UPDATE food_items SET name = ?, restaurant_name = ?, image_url = ?, location = ?, price = ?, category = ?, rating = ? WHERE id = ?', 
                   [name, restaurant_name, image_url, location, price, category, rating, id]);
};

exports.deleteFood = async (id) => {
    await db.query('DELETE FROM food_items WHERE id = ?', [id]);
};

exports.searchFood = async (query) => {
    const sql = 'SELECT * FROM food_items WHERE name LIKE ? OR restaurant_name LIKE ? OR category LIKE ?';
    const searchTerm = `%${query.keyword}%`;
    const [rows] = await db.query(sql, [searchTerm, searchTerm, searchTerm]);
    return rows;
};
