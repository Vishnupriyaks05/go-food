const db = require('../config/db');

exports.addUser = async (userData) => {
    const { name, email, phone, age, gender, password } = userData;
    await db.query('INSERT INTO users (name, email, phone, age, gender, password) VALUES (?, ?, ?, ?, ?, ?)', 
                   [name, email, phone, age, gender, password]);
};

exports.getUserByEmail = async (email) => {
    const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
    return rows[0];
};
