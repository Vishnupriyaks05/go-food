const { addFood, updateFood, deleteFood, searchFood } = require('../models/foodModel');

exports.addFood = async (req, res) => {
    try {
        console.    log('addFood API called')
        console.log('Request body:', req.body);
        const foodId = await addFood(req.body);
        console.log('Food successfully added with ID:', foodId);
        res.status(201).json({ message: 'Food added successfully', foodId });
    } catch (err) {
        console.error('Error in addFood API:', err.message);
        res.status(500).json({ message: 'Error adding food', error: err.message });
    }
};

exports.updateFood = async (req, res) => {
    try {
        console.    log('updateFood API called')
        console.log('Request body:', req.body);
        await updateFood(req.params.id, req.body);
        console.log('Food successfully Updated');
        res.status(200).json({ message: 'Food updated successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Error updating food', error: err.message });
    }
};

exports.deleteFood = async (req, res) => {
    try {
        await deleteFood(req.params.id);
        res.status(200).json({ message: 'Food deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Error deleting food', error: err.message });
    }
};

exports.searchFood = async (req, res) => {
    try {
        const results = await searchFood(req.query);
        res.status(200).json(results);
    } catch (err) {
        res.status(500).json({ message: 'Error searching food', error: err.message });
    }
};
