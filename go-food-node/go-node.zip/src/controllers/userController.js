const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { addUser, getUserByEmail } = require('../models/userModel');
const jwtConfig = require('../config/jwtConfig');

exports.register = async (req, res) => {
    const { name, email, phone, age, gender, password } = req.body;

    console.log('Register API called with data:', { name, email, phone, age, gender });

    const hashedPassword = await bcrypt.hash(password, 10);

    try {
        await addUser({ name, email, phone, age, gender, password: hashedPassword });
        console.log('User registered successfully:', { name, email });
        res.status(201).json({ message: 'User registered successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Error registering user', error: err.message });
    }
};

exports.login = async (req, res) => {
    const { email, password } = req.body;
    const user = await getUserByEmail(email);

    console.log("User login called: ", email);

    if (!user) return res.status(401).json({ message: 'Invalid email or password' });

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) return res.status(401).json({ message: 'Invalid email or password' });

    const token = jwt.sign({ id: user.id, email: user.email }, jwtConfig.secret, { expiresIn: '1h' });

    console.log("Login successful for email: ", email);
    console.log("Generated JWT token: ", token);


    res.json({ token });
};
