const express = require('express');
const { addFood, updateFood, deleteFood, searchFood } = require('../controllers/foodController');
const authenticateJWT = require('../middleware/authenticateJWT');
const router = express.Router();

// Add a new food item
router.post('/', authenticateJWT, addFood);

// Update an existing food item
router.put('/:id', authenticateJWT, updateFood);

// Delete a food item
router.delete('/:id', authenticateJWT, deleteFood);

// Search for food items
router.get('/search', searchFood);

module.exports = router;
